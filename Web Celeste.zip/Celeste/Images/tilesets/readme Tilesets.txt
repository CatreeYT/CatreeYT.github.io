Hi future me, this is how tilesets are ordered!

0: Top
1: Bottom
2: Left
3: Right
4: Peninsula Bottom
5: Peninsula Top
6: Peninsula Left
7: Peninsula Right
10: All sides
11: Top=left
12: Top-right
13: Botton-left
14: Bottom-right