binds.jump = "c";
binds.dash = "x";
binds.climb = "z";
binds.climbUp = "ArrowUp";
binds.climbDown = "ArrowDown"

var playerDefaultWidth = 16;
var playerDefaultHeight = 18;
var defaultExtraPixelsStanding = 4;

player.width = playerDefaultWidth;
player.height = playerDefaultHeight;
player.extraPixelsStanding = defaultExtraPixelsStanding;

var playerCrouchHeight = 9;
var crouchExtraPixels = 2;

pixelsOfTest = 4.1;

var animFrame = 0;
var currentAnim = "Idle";

var madelineIdleAnimation = [];
for(var i = 0; i <= 8; ++i){
    madelineIdleAnimation.push(new img("Images/Madeline/idleAnim/idle0" + i + ".png", -24, -42));
}

var madelineClimbAnimation = [];
for(var i = 0; i <= 5; ++i){
    madelineClimbAnimation.push(new img("Images/Madeline/climbAnim/climb" + (i < 10 ? "0" : "") + i + ".png", -26, -42));
}

var madelineWalkAnimation = [];
for(var i = 0; i <= 11; ++i){
    madelineWalkAnimation.push(new img("Images/Madeline/Walk/walk" + (i < 10 ? "0" : "") + i + ".png", -24, -42));
}

var madelinePushAnimation = [];
for(var i = 0; i <= 15; ++i){
    madelinePushAnimation.push(new img("Images/Madeline/Push/push" + (i < 10 ? "0" : "") + i + ".png", -24, -42));
}

var madelineJumpAnimation = [];
for(var i = 0; i <= 3; ++i){
    madelineJumpAnimation.push(new img("Images/Madeline/Jump/Jump Fast/jumpFast0" + i + ".png", -24, -42));
}

var madelineDash = new img("Images/Madeline/dashAnim/dash01.png", -24, -42);
var madelineFall = madelineJumpAnimation[3];
var madelineCrouch = new img("Images/Madeline/duck.png", -24, -53);

var madelineBangsRefill = new img("Images/Madeline/Bangs/bangs00.png");

var madelineBangsDashesDefault = [
    new img("Images/Madeline/Bangs/bangs0dash.png", -2, -8),
    new img("Images/Madeline/Bangs/bangs1dash.png", -2, -8),
];
var madelineChristmasDashes = [
    new img("Images/Madeline/Bangs/christmas0dash.png", -2, -14),
    new img("Images/Madeline/Bangs/christmas1dash.png", -2, -14),
];
var hairImages = [
    madelineBangsDashesDefault,
    madelineChristmasDashes,
];
var hairInFront = [
    false,
    true
];
var hairImage = 1;
var madelineBangsDashes = hairImages[hairImage];

player.sprite = madelineIdleAnimation[0];

var dirtTileset = new tileset("Images/tilesets/dirt/dirtTileset.png", 0, 0);
var snowTileset = new tileset("Images/tilesets/snow/snowTileset.png", 0, 0);
var girderTileset = new tileset("Images/tilesets/girder/girderTileset.png", 0, 0);


var dashSound = new Audio("Audio/Sound Effects/dash.wav");

var walkOnDirt = [];
var walkOnSnow = [];
var walkOnGirder = [];

for(var i = 1; i <= 5; ++i){
    walkOnDirt.push(new Audio("Audio/Sound Effects/Walk or Land/Dirt/land_00_dirt_0" + i + ".wav"));
    walkOnSnow.push(new Audio("Audio/Sound Effects/Walk or Land/Snow/land_00_snowsoft_0" + i + ".wav"));
    walkOnGirder.push(new Audio("Audio/Sound Effects/Walk or Land/Girder/land_01_metalgirder_0" + i + ".wav"));
}

var crystalHeartBlue = new img("Images/Extra/Crystal Heart Blue.png")

player.stretch = 1;
player.speedOfDestretch = 0.02;

var normalAirFriction = 0.3;
player.airFriction = normalAirFriction;
var defaultGravity = 0.18;
var slideGravity = 0.04;

player.maxDashes = 1;
player.dashesRemaining = player.maxDashes;
player.dashEnabled = true;
player.dashPower = 8;
player.dashLength = 8;
player.dashing = false;
var dashAfterimages = [];

player.stamina = 100;
player.climbing = false;
player.climbDistance = 0;
player.sliding = false;
player.climbSpeed = 1.5;
player.climbJump = false;

player.jumpForce = 5;

player.die = function(){
    player.x = player.spawnX;
    player.y = player.spawnY;
    player.fs = 0;
    player.hs = 0;
    player.dashing = false;
    player.dashesRemaining = player.maxDashes;
    player.stamina = 100;
};

function room(width, height){
    this.spawns = []; // Points you spawn from after dying. Gets set when entering room.
    this.transitions = []; // Points the player can go to another room
    this.triggers = []; // Checks if player is touching it, then runs a function
    this.crystalHeart; // When collected, end the map
    this.extraThings = function(){};

    this.width = width;
    this.height = height;

    function checkTop(position, length){
        return player.y < 0 && player.x + player.width > position && player.x < position + length;
    }
    function checkRight(position, length){
        return player.x > screenWidth * 16 && player.y + player.height > position && player.y < position + length;
    }
    function checkBottom(position, length){
        return player.y + player.height > screenHeight * 16 && player.x + player.width > position && player.x < position + length;
    }
    function checkLeft(position, length){
        return player.x < 0 && player.y + player.height > position && player.y < position + length;
    }
    this.addTransition = function(moveTo, sideOfEntry, entrancePosition, exitPosition, length){
        entrancePosition *= 16;
        exitPosition *= 16;
        length *= 16;
        switch(sideOfEntry){
            // Top
            case 0: {
                this.transitions.push([moveTo, entrancePosition, {x: exitPosition, y: chapters[currentChapter][moveTo].height * 16 - player.height - 6}, length, checkTop]);
                break;
            }
            // Right
            case 1: {
                this.transitions.push([moveTo, entrancePosition, {x: 6, y: exitPosition}, length, checkRight]);
                break;
            }
            // Bottom
            case 2: {
                this.transitions.push([moveTo, entrancePosition, {x: exitPosition, y: 0}, length, checkBottom]);
                break;
            }
            // Left
            case 3: {
                this.transitions.push([moveTo, entrancePosition, {x: chapters[currentChapter][moveTo].width * 16 - player.width - 6, y: exitPosition}, length, checkLeft]);
                break;
            }
        }
    };
    this.checkTransitions = function(){
        for(var i = 0; i < this.transitions.length; ++i){
            if(this.transitions[i][4](this.transitions[i][1], this.transitions[i][3])){
                currentRoom = this.transitions[i][0];
                refToRoom = chapters[currentChapter][currentRoom];
                level2d = refToRoom.content;
                if(this.transitions[i][4] === checkTop || this.transitions[i][4] === checkBottom){
                    player.x = (player.x - this.transitions[i][1]) + this.transitions[i][2].x
                } else {
                    player.x = this.transitions[i][2].x;
                }
                if(this.transitions[i][4] === checkLeft || this.transitions[i][4] === checkRight){
                    player.y = (player.y - this.transitions[i][1]) + this.transitions[i][2].y
                } else {
                    player.y = this.transitions[i][2].y;
                }
                player.dashesRemaining = player.maxDashes;
                screenWidth = refToRoom.width;
                screenHeight = refToRoom.height;
                convertLevel2dto1d();
                player.getSpawn();
                break;
            }
        }
    };

    this.addSpawn = function(tileX, tileY){
        this.spawns.push({x: tileX * 16, y: tileY * 16+12})
    };
    
    this.addTrigger = function(x, y, w, h, funcToRun, runOnce = -1){
        this.triggers.push([x*16, y*16, w*16, h*16, funcToRun, runOnce])
    };
    this.checkTriggers = function(){
        for(var i = 0; i < this.triggers.length; ++i){
            if(touching(player.x, player.y, player.width, player.height, this.triggers[i][0], this.triggers[i][1], this.triggers[i][2], this.triggers[i][3])){
                if(this.triggers[i][5] !== 0){
                    --this.triggers[i][5];
                    this.triggers[i][4]();
                }
            }
        }
    };
    this.drawCrystalHeart = function(){
        if(this.crystalHeart){
            crystalHeartBlue.draw(this.crystalHeart.x, this.crystalHeart.y, 2, 2, false, false);
        }
    }
    this.checkCrystalHeart = function(){
        if(this.crystalHeart && touching(player.x, player.y, player.width, player.height, this.crystalHeart.x, this.crystalHeart.y, 36, 34)){
            if(player.dashing){
                ++currentChapter;
                currentRoom = 0;
                refToRoom = chapters[currentChapter][currentRoom];
                level2d = refToRoom.content;
                player.dashesRemaining = player.maxDashes;
                screenWidth = refToRoom.width;
                screenHeight = refToRoom.height;
                convertLevel2dto1d();
                player.x = player.spawnX;
                player.y = player.spawnY;
                player.fs = 0;
                player.hs = 0;
            } else {
                player.dashesRemaining = player.maxDashes;
                var mag = dist(0, 0, (this.crystalHeart.x + 18) - (player.x + player.width/2), (this.crystalHeart.y + 17) - (player.y + player.height/2))
                player.hs = ((player.x + player.width/2) - (this.crystalHeart.x + 18))/mag;
                player.fs = ((player.y + player.height/2) - (this.crystalHeart.y + 17))/mag;
                while(touching(player.x, player.y, player.width, player.height, this.crystalHeart.x, this.crystalHeart.y, 36, 34)){
                    player.x += player.hs;
                    player.y += player.fs;
                }
                player.hs *= 8;
                player.fs *= 4;
            }
        }
    }

    this.content = [];
    for(var i = 0; i < this.width; ++i){
        this.content.push([])
        for(var j = 0; j < this.height; ++j){
            this.content[i].push(0);
        }
    }
    this.blockOfTiles = function(x, y, w, h, tilesetToUse){
        for(var i = x; i < x + w; ++i){
            for(var j = y; j < y + h; ++j){
                this.content[i][j] = tilesetToUse;
            }
        }
    }
    this.setAreaContent = function(levelArray){
        this.content = levelArray;
        this.width = levelArray.length;
        this.height = levelArray[0].length;
    }
}

player.dash = function(direction){
    if(player.dashEnabled){
        if(player.dashesRemaining > 0){
            player.fs = cos(direction) * player.dashPower;
            player.hs = sin(direction) * player.dashPower;
            --player.dashesRemaining;
            player.dashing = true;
            player.airFriction = 0;
            player.jumpInfluenceFrames = 0;
            player.canMove = false;
            for(var i = 1; i <= 3; ++i){
                time.timers.push([function(){
                    dashAfterimages.push(new PVector(player.x, player.y));
                }, 2*i]);
            }
            time.timers.push([function(){player.canMove = true; dashAfterimages = [];}, player.dashLength+4])
            time.timers.push([function(){
                player.airFriction = normalAirFriction;
                if(player.dashing){
                    player.fs /= 3;
                    player.hs /= 2;
                } else {
                    player.fs /= 1.5;
                    player.hs /= 1.5;
                }
                player.dashing = false;
                player.airFriction = normalAirFriction;
            }, player.dashLength]);
        }
    }
};
function onLanding(x, y, w, h, friction){
    stand(x, y, w, h, !player.dashing ? friction : 0);
    player.dashesRemaining = player.maxDashes;
    player.canMove = true;
    player.stamina = 100;
    player.stretch = 1;
}
function ground(x, y, w, h){
    var g = new block(x, y, w, h, 0.4, new colorObj(255, 255, 255), onLanding);
    return g;
}

var tilesets = [
    0,
    dirtTileset,
    snowTileset,
    girderTileset,
];

var screenWidth = ceil(width / 16);
var screenHeight = ceil(height / 16);

var level2d = [];

function resetLevel2d(){
    level2d = [];
    for(var i = 0; i < screenWidth; ++i){
        level2d.push([])
        for(var j = 0; j < screenHeight; ++j){
            level2d[i].push(0);
        }
    }
}

function blockOfTiles(x, y, w, h, tilesetToUse){
    for(var i = x; i < x + w; ++i){
        for(var j = y; j < y + h; ++j){
            level2d[i][j] = tilesetToUse;
        }
    }
}

var currentRoom = 0;
var currentChapter = 0;

var prologue = [
    new room(54, 20),
    new room(ceil(width / 16), ceil(height / 16)),
    new room(57, 24),
    new room(36, ceil(height / 16)),
    new room(117, ceil(height / 16)),
    new room(null, null),
];
var forsakenCity = [
    new room(54, ceil(height / 16)),
];

var chapters = [
    prologue,
    forsakenCity,
];

prologue[5].setAreaContent([[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],[0,0,0,1,1,0,0,1,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],[0,0,1,0,0,1,0,0,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],[0,0,1,0,0,1,0,0,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],[0,0,1,0,0,1,0,0,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],[0,0,0,1,0,0,1,1,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],[0,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],[0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],[0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,1,0,1,1,1,1,1,1,1],[0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1],[0,0,0,0,0,0,0,0,1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1],[0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1],[0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1],[0,0,0,0,1,1,1,1,1,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1],[0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,1,0,1,1,1,1,1,1,1],[0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],[0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],[0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],[0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],[0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],[0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],[0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],[0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1],]);
prologue[5].addSpawn(5, 5)

prologue[0].blockOfTiles(0, 16, 15, 4, 1)
prologue[0].blockOfTiles(11, 14, 5, 4, 2)
prologue[0].blockOfTiles(21, 17, 6, 3, 1)
prologue[0].blockOfTiles(24, 14, 2, 3, 1)
prologue[0].blockOfTiles(26, 16, 1, 1, 1)
prologue[0].blockOfTiles(30, 14, 1, 1, 1)
prologue[0].blockOfTiles(31, 14, 5, 6, 1)
prologue[0].blockOfTiles(36, 14, 1, 2, 1)
prologue[0].blockOfTiles(42, 16, 1, 3, 1)
prologue[0].blockOfTiles(43, 16, 3, 4, 1)
prologue[0].blockOfTiles(45, 13, 2, 5, 1)
prologue[0].blockOfTiles(50, 17, 1, 1, 1)
prologue[0].blockOfTiles(51, 17, 3, 3, 1)
prologue[0].addTransition(1, 3, 0, 0, height / 16);
prologue[0].addTransition(2, 1, 0, 4, height / 16);
prologue[0].addSpawn(2, 14)
prologue[0].addSpawn(51, 15);

prologue[1].blockOfTiles(0, 16, 86, 30, 1)
prologue[1].blockOfTiles(0, 15, 4, 1, 1)
prologue[1].blockOfTiles(23, 15, 3, 1, 1)
prologue[1].blockOfTiles(23, 14, 2, 1, 1)
prologue[1].blockOfTiles(51, 15, 4, 1, 1)
prologue[1].addTransition(0, 1, 0, 0, height / 16);

prologue[2].blockOfTiles(0, 21, 7, 4, 1)
prologue[2].blockOfTiles(7, 21, 1, 1, 1)
prologue[2].blockOfTiles(12, 20, 4, 1, 1)
prologue[2].blockOfTiles(13, 21, 3, 1, 1)
prologue[2].blockOfTiles(14, 22, 5, 3, 1)
prologue[2].blockOfTiles(16, 13, 4, 9, 1)
prologue[2].blockOfTiles(20, 13, 1, 4, 1)
prologue[2].blockOfTiles(24, 17, 4, 2, 1)
prologue[2].blockOfTiles(27, 19, 1, 1, 1)
prologue[2].blockOfTiles(25, 18, 2, 7, 1)
prologue[2].blockOfTiles(32, 10, 2, 6, 1)
prologue[2].blockOfTiles(33, 13, 2, 9, 1)
prologue[2].blockOfTiles(34, 16, 5, 9, 1)
prologue[2].blockOfTiles(42, 21, 2, 1, 1)
prologue[2].blockOfTiles(44, 21, 5, 4, 1)
prologue[2].blockOfTiles(45, 20, 2, 1, 1)
prologue[2].blockOfTiles(47, 18, 2, 3, 1)
prologue[2].blockOfTiles(49, 18, 1, 1, 1)
prologue[2].blockOfTiles(44, 3, 3, 6, 1)
prologue[2].blockOfTiles(44, 9, 2, 5, 1)
prologue[2].blockOfTiles(53, 16, 1, 4, 1)
prologue[2].blockOfTiles(54, 11, 3, 14, 1)
prologue[2].addTransition(0, 3, 0, -4, height / 16);
prologue[2].addTransition(3, 1, 0, 5, height / 16);
prologue[2].addSpawn(4, 19);
prologue[2].addSpawn(54, 9);

prologue[3].blockOfTiles(0, 16, 7, 3, 1)
prologue[3].blockOfTiles(7, 15, 1, 4, 1)
prologue[3].blockOfTiles(8, 13, 2, 6, 1)
prologue[3].blockOfTiles(10, 10, 16, 9, 1)
prologue[3].blockOfTiles(26, 12, 10, 7, 1)
prologue[3].addTransition(2, 3, 0, -5, height / 16);
prologue[3].addTransition(4, 1, 0, 4, height / 16);

prologue[4].blockOfTiles(0, 16, 8, 1, 1);
prologue[4].blockOfTiles(0, 17, 7, 2, 1);
prologue[4].blockOfTiles(0, 19, 6, 2, 1);
prologue[4].blockOfTiles(0, 21, 5, 2, 1);
prologue[4].blockOfTiles(8, 16, 52, 1, 1);
prologue[4].blockOfTiles(64, 16, 32, 1, 1);
prologue[4].blockOfTiles(106, 16, 3, 4, 1);
prologue[4].blockOfTiles(109, 16, 2, 5, 1);
prologue[4].blockOfTiles(111, 16, 6, 7, 1);
prologue[4].blockOfTiles(114, 15, 1, 1, 1);
prologue[4].blockOfTiles(115, 13, 1, 3, 1);
prologue[4].blockOfTiles(116, 11, 1, 5, 1);
prologue[4].addTransition(3, 3, 0, -4, height / 16);
prologue[4].addSpawn(4, 14);

prologue[4].crystalHeart = new PVector(1750, 200)

forsakenCity[0].blockOfTiles(0, 16, 15, 4, 3)

var refToRoom = chapters[currentChapter][currentRoom];

level2d = refToRoom.content;
screenWidth = refToRoom.width;
screenHeight = refToRoom.height;

function convertLevel2dto1d(){
    level = [];
    for(var i = 0; i < screenWidth; ++i){
        for(var j = 0; j < screenHeight; ++j){
            if(level2d[i][j] > 0){
                var tileOnTop = j - 1 < 0 ? true : level2d[i][j-1] !== 0;
                var tileOnBottom = j + 1 > screenHeight - 1 ? true : level2d[i][j+1] !== 0;
                var tileOnLeft = i - 1 < 0 ? true : level2d[i-1][j] !== 0;
                var tileOnRight = i + 1 > screenWidth - 1 ? true : level2d[i+1][j] !== 0;
                var tileOnTL = (i - 1 < 0 || j - 1 < 0) ? true : level2d[i-1][j-1] !== 0;
                var tileOnTR = (i + 1 > screenWidth - 1 || j - 1 < 0) ? true : level2d[i+1][j-1] !== 0;
                var tileOnBL = (i - 1 < 0 || j + 1 > screenHeight - 1) ? true : level2d[i-1][j+1] !== 0;
                var tileOnBR = (i + 1 > screenWidth - 1 || j + 1 > screenHeight - 1) ? true : level2d[i+1][j+1] !== 0;
                if(!tileOnTop && !tileOnRight && !tileOnLeft && !tileOnBottom){
                    level.push(tile(i, j, tilesets[level2d[i][j]], 8));
                } else {
                    if(!tileOnTop && tileOnLeft && tileOnRight && tileOnBottom){
                        level.push(tile(i, j, tilesets[level2d[i][j]], 0));
                    } else if (tileOnTop && tileOnLeft && tileOnRight && !tileOnBottom) {
                        level.push(tile(i, j, tilesets[level2d[i][j]], 1))
                    } else if (tileOnTop && !tileOnLeft && tileOnRight && tileOnBottom) {
                        level.push(tile(i, j, tilesets[level2d[i][j]], 2));
                    } else if (tileOnTop && tileOnLeft && !tileOnRight && tileOnBottom) {
                        level.push(tile(i, j, tilesets[level2d[i][j]], 3));
                    } else if (!tileOnTop && !tileOnLeft && !tileOnRight && tileOnBottom) {
                        level.push(tile(i, j, tilesets[level2d[i][j]], 4));
                    } else if (tileOnTop && !tileOnLeft && !tileOnRight && !tileOnBottom) {
                        level.push(tile(i, j, tilesets[level2d[i][j]], 5));
                    } else if (!tileOnTop && !tileOnLeft && tileOnRight && !tileOnBottom) {
                        level.push(tile(i, j, tilesets[level2d[i][j]], 6));
                    } else if (!tileOnTop && tileOnLeft && !tileOnRight && !tileOnBottom) {
                        level.push(tile(i, j, tilesets[level2d[i][j]], 7));
                    } else if (!tileOnTop && !tileOnLeft && tileOnRight && tileOnBottom && tileOnBR) {
                        level.push(tile(i, j, tilesets[level2d[i][j]], 9));
                    } else if (!tileOnTop && tileOnLeft && !tileOnRight && tileOnBottom && tileOnBL) {
                        level.push(tile(i, j, tilesets[level2d[i][j]], 10));
                    } else if (tileOnTop && !tileOnLeft && tileOnRight && !tileOnBottom && tileOnTR) {
                        level.push(tile(i, j, tilesets[level2d[i][j]], 11));
                    } else if (tileOnTop && tileOnLeft && !tileOnRight && !tileOnBottom && tileOnTL) {
                        level.push(tile(i, j, tilesets[level2d[i][j]], 12));
                    } else if (tileOnTop && tileOnLeft && tileOnRight && tileOnBottom && !tileOnTL) {
                        level.push(tile(i, j, tilesets[level2d[i][j]], 13));
                    } else if (tileOnTop && tileOnLeft && tileOnRight && tileOnBottom && !tileOnTR) {
                        level.push(tile(i, j, tilesets[level2d[i][j]], 14));
                    } else if (tileOnTop && tileOnLeft && tileOnRight && tileOnBottom && !tileOnBL) {
                        level.push(tile(i, j, tilesets[level2d[i][j]], 15));
                    } else if (tileOnTop && tileOnLeft && tileOnRight && tileOnBottom && !tileOnBR) {
                        level.push(tile(i, j, tilesets[level2d[i][j]], 16));
                    } else if (!tileOnTop && tileOnLeft && tileOnRight && !tileOnBottom) {
                        level.push(tile(i, j, tilesets[level2d[i][j]], 17));
                    } else if (tileOnTop && !tileOnLeft && !tileOnRight && tileOnBottom) {
                        level.push(tile(i, j, tilesets[level2d[i][j]], 18));
                    } else {
                        //level.push(tile(i, j, tilesets[level2d[i][j]], 9));
                    }
                }
            }
        }
    }
}

convertLevel2dto1d();

function tile(x, y, tilesetToUse, tileInSet){
    var g = new block(x * 16, y * 16, 16, 16, 0.4, tilesetToUse, onLanding);
    g.tileInSet = tileInSet;
    return g;
}
player.onJump = function(){
    player.dashing = false;
    player.stretch = 0.6;
    player.speedOfDestretch = 0.03;
    player.y -= 8;
}
player.getSpawn = function(){
    if(refToRoom.spawns.length > 0){
        var distances = [];
        for(var i = 0; i < refToRoom.spawns.length; ++i){
            distances.push(dist(player.x, player.y, refToRoom.spawns[i].x, refToRoom.spawns[i].y));
        }
        var curIndex = 0;
        var curValue = distances[curIndex];
        for(var i = 0; i < distances.length; ++i){
            if(distances[i] < curValue){
                curValue = distances[i];
                curIndex = i;
            }
        }
        player.spawnX = refToRoom.spawns[curIndex].x;
        player.spawnY = refToRoom.spawns[curIndex].y;
    } else {
        player.spawnX = 10;
        player.spawnY = 10;
    }
};
player.getSpawn();
function extraControls(){
    if(inputStart[binds.dash]){
        if(pressing[UP] && !pressing[RIGHT] && !pressing[LEFT] && !pressing[DOWN]){
            player.dash(180);
        } else if(!pressing[UP] && pressing[RIGHT] && !pressing[LEFT] && !pressing[DOWN]){
            player.dash(90);
        } else if(!pressing[UP] && !pressing[RIGHT] && pressing[LEFT] && !pressing[DOWN]){
            player.dash(270)
        } else if(!pressing[UP] && !pressing[RIGHT] && !pressing[LEFT] && pressing[DOWN]){
            player.dash(0)
        } else if(!pressing[UP] && !pressing[RIGHT] && pressing[LEFT] && pressing[DOWN]){
            player.dash(315);
        } else if(!pressing[UP] && pressing[RIGHT] && !pressing[LEFT] && pressing[DOWN]){
            player.dash(45);
        } else if(pressing[UP] && pressing[RIGHT] && !pressing[LEFT] && !pressing[DOWN]){
            player.dash(135);
        } else if(pressing[UP] && !pressing[RIGHT] && pressing[LEFT] && !pressing[DOWN]){
            player.dash(225);
        }
    }
    if(player.coyoteFramesLeft > 0){
        if(pressing[binds.climbDown]){
            if(!player.crouching){
                player.y += 10;
            }
            player.crouching = true;
        } else {
            if(player.crouching){
                player.y -= 10;
                player.stretch = 0.7;
                player.speedOfDestretch = 0.1;
            }
            player.crouching = false;
        }
    } else {
        if(player.crouching){
            player.y -= 10;
            player.stretch = 0.8;
        }
        player.crouching = false;
    }
    if(player.crouching){
        player.height = playerCrouchHeight;
        player.extraPixelsStanding = crouchExtraPixels;
        player.canMove = false;
    } else {
        player.height = playerDefaultHeight;
        player.extraPixelsStanding = defaultExtraPixelsStanding;
        player.canMove = true;
    }
    player.sliding = false;
    player.pushing = false;
    if(!player.dashing){
        for(var i = 0; i < level.length; ++i){
            if(touching(level[i].x, level[i].y, level[i].w, level[i].h, player.x + player.width*0.5 + player.direction*(player.width+player.climbDistance), player.y + 2, 1, 12)){
                if(player.fs >= 0){
                    if(player.coyoteFramesLeft > 0){
                        if(!(pressing[binds.moveLeft] && pressing[binds.moveRight]) && (pressing[binds.moveLeft] || pressing[binds.moveRight])){
                            player.pushing = true;
                        }
                    } else {
                        player.sliding = true;
                    }
                }
                if(pressing[binds.climb] && player.stamina > 0){
                    if(!pressing[binds.climbDown] && !player.climbJump){
                        player.climbing = true;
                        if(player.direction === 1){
                            player.x = level[i].x - player.width
                        } else {
                            player.x = level[i].x + level[i].w
                        }
                        player.sliding = false;
                        player.fs = 0;
                        if(inputStart[binds.jump]){
                            if(pressing[binds.moveLeft] || pressing[binds.moveRight]){
                                player.canMove = false;
                                player.climbJump = true;
                                player.climbing = false;
                                player.hs = -6 * player.direction;
                                player.fs = -2;
                                time.timers.push([function(){
                                    player.climbJump = false;
                                }, 20])
                                time.timers.push([function(){
                                    player.canMove = true;
                                }, 40])
                            } else {
                                player.climbJump = true;
                                player.sliding = false;
                                player.fs = -player.jumpForce;
                                player.stamina -= 25;
                                time.timers.push([function(){player.climbJump = false;}, 24]);
                                if(player.stamina <= 0){break;}
                            }
                        }
                        if(pressing[binds.climbUp]){
                            player.fs = -player.climbSpeed;
                            player.stamina -= 0.69;
                        } else {
                            player.stamina -= 0.151;
                        }
                    } else {
                        player.sliding = true;
                    }
                } else {
                    player.climbing = false;
                }
                break;
            } else {
                player.climbing = false;
                player.sliding = false;
            }
        }
        if(player.climbing){
            player.canMove = false;
            player.hs = 0;
        } else {
            if(!player.crouching){
                player.canMove = true;
            }
        }
        if(player.sliding){
            GRAVITY = slideGravity;
            if(inputStart[binds.jump]){
                player.canMove = false;
                player.hs = -6 * player.direction;
                player.fs = -3;
                time.timers.push([function(){
                    player.canMove = true;
                }, 20])
            }
        } else {
            GRAVITY = defaultGravity;
        }
    }
    // For testing purposes
    if(inputStart["q"]){
        player.dashEnabled = !player.dashEnabled;
    }
    if(player.y + player.height/2 > screenHeight * 16){
        player.die();
    }
    if(inputStart["r"]){
        player.die();
    }
}
function setSprite(){
    ++animFrame;
    var startingAnim = currentAnim;
    if(player.coyoteFramesLeft > 0){
        player.sprite = madelineIdleAnimation[floor(animFrame/6) % madelineIdleAnimation.length];
        currentAnim = "idle"
    }
    if(player.fs > GRAVITY){
        player.sprite = madelineFall;
        currentAnim = "fall"
    } else {
        if(player.fs >= 0){
            if(!(pressing[binds.moveLeft] && pressing[binds.moveRight]) && (pressing[binds.moveLeft] || pressing[binds.moveRight])){
                player.sprite = madelineWalkAnimation[floor(animFrame/3) % madelineWalkAnimation.length];
                currentAnim = "walk"
            }
        } else {
            player.sprite = madelineJumpAnimation[min(floor(animFrame/4), madelineJumpAnimation.length - 1)];
            currentAnim = "jump"
        }
    }
    if(player.climbing){
        if(!pressing[binds.climbUp]){
            player.sprite = madelineClimbAnimation[0];
            currentAnim = "climbStill"
        } else {
            player.sprite = madelineClimbAnimation[floor(animFrame/5) % madelineClimbAnimation.length];
            currentAnim = "climbMove"
        }
    }
    if(player.sliding){
        player.sprite = madelineClimbAnimation[0];
        currentAnim = "slidingOnWall";
    }
    if(player.pushing){
        player.sprite = madelinePushAnimation[floor(animFrame/5) % madelinePushAnimation.length];
        currentAnim = "pushingOnWall"
    }
    if(player.dashing){
        player.sprite = madelineDash;
        currentAnim = "dashing"
    }
    if(player.crouching){
        player.sprite = madelineCrouch;
        currentAnim = "crouching";
        if(!(pressing[binds.moveLeft] && pressing[binds.moveRight])){
            if(pressing[binds.moveLeft]){player.direction = -1;}
            if(pressing[binds.moveRight]){player.direction = 1;}
        }
    }
    if(startingAnim !== currentAnim){
        animFrame = 0;
    }

    if(currentAnim === "walk"){
        if(floor(animFrame%20) === 0){
            var chosen = floor(random(0, walkOnDirt.length));
            walkOnDirt[chosen].currentTime = 0;
            walkOnDirt[chosen].volume = 0.2
            walkOnDirt[chosen].play()
        }
    }
    if(currentAnim === "dashing"){
        if(floor(animFrame) === 0){
            dashSound.currentTime = 0;
            dashSound.volume = 0.2;
            dashSound.play();
        }
    }

    if(player.stretch > 1){
        player.stretch -= player.speedOfDestretch;
        if(player.stretch < 1){
            player.stretch = 1;
        }
    }
    if(player.stretch < 1){
        player.stretch += player.speedOfDestretch;
        if(player.stretch > 1){
            player.stretch = 1;
        }
    }
}
function setCamPosition(){
    var xPos = player.x - 0.5 * (width + player.width);
    var yPos = player.y - 0.5 * (height + player.height);
    translate(-max(min(xPos, screenWidth * 16 - width), 0), -max(min(yPos, screenHeight * 16 - height), 0));
}
var debugEnabled = false;
var debugSettings = [
    false, // Show player tile overlay
];
function debugThings(){
    if(inputStart["d"]){debugEnabled = !debugEnabled;}
    if(debugEnabled){
        fill(255, 255, 255)
        fillText("X: " + floor(player.x), 20-transX, 20-transY);
        fillText("Y: " + floor(player.y), 20-transX, 50-transY);
        fillText("TileX: " + round(player.x/16), 100-transX, 20-transY);
        fillText("TileY: " + floor(player.y/16), 100-transX, 50-transY);
        if(inputStart["f"]){debugSettings[0] = !debugSettings[0];}
        if(debugSettings[0]){
            rect(round(player.x/16) * 16, floor(player.y/16) * 16, 16, 16)
            if(inputStart["s"]){navigator.clipboard.writeText(floor(player.x/16).toString() + ", " + floor(player.y/16).toString())}
        }
    }
}